//
//  LineViewController.m
//  DrawLineApp
//
//  Created by 一只老母猪 on 2019/9/9.
//  Copyright © 2019 〝Cow﹏. All rights reserved.
//

#import "LineViewController.h"
#import "LineView.h"

@interface LineViewController ()

@end

@implementation LineViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    LineView * lineView = [[LineView alloc] initWithFrame:CGRectMake(0, WH_SCALE(120), SCREEN_WIDTH, WH_SCALE(300))];
    [lineView showBtnView_UI];
    [self.view addSubview:lineView];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

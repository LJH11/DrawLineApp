//
//  LineView.m
//  DrawLineApp
//
//  Created by 一只老母猪 on 2019/9/9.
//  Copyright © 2019 〝Cow﹏. All rights reserved.
//

#import "LineView.h"
#import "BUIControl.h"
#import "UIView+PSFrame.h"

/*
把前段时间开发的画线点击触发事件的功能整理一下、
需求赶大概用了2-3开发模块之后提交测试吧、之后就在调视频动画参数
有需要的小伙伴也可方便提供下思路将就看看
 */

@implementation LineView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (NSArray *)dataArray
{
    if (!_dataArray)
    {
        _dataArray = @[@[@"", @"btnAddImg"],
                       @[@"", @"btnAddImg"],
                       @[@"", @"btnAddImg"],
                       @[@"", @"btnAddImg"],
                       @[@"名字5", @"rjcs_me"],
                       @[@"", @"btnAddImg"],
                       @[@"", @"btnAddImg"],
                       @[@"", @"btnAddImg"],
                       @[@"", @"btnAddImg"]];
    }
    return _dataArray;
}

-(void)showBtnView_UI
{
    self.backgroundColor = [UIColor clearColor];
    for (int i = 0; i < [self.dataArray count]; i++)
    {
        NSDictionary * btnDic = self.dataArray[i];
        [self showBtnTapAction:btnDic supView:self btnINdex:i];
    }
}

-(void)showBtnTapAction:(NSDictionary*)btnDic supView:(UIView*)supVc btnINdex:(int)btnINdex
{
    self.backgroundColor = [UIColor clearColor] ;
    UIButton * iconBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    iconBtn.frame = CGRectMake(WH_SCALE(13) + WH_SCALE(111) * (btnINdex%3),  WH_SCALE(111) * (btnINdex/3), WH_SCALE(73), WH_SCALE(73));
    iconBtn.backgroundColor = [UIColor whiteColor];
    iconBtn.layer.masksToBounds = YES;
    iconBtn.tag = 100 + btnINdex;
    iconBtn.layer.cornerRadius = WH_SCALE(15);
    //注意是否获取hhttp的头像显示
    [iconBtn handleControlEvent:UIControlEventTouchUpInside withBlock:^(UIButton * sender)
     {
         [self tapBtnAction:sender];
     }];
    [supVc addSubview:iconBtn];
    
    UIPanGestureRecognizer *panRec = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(btnPanAction:)];
    [iconBtn addGestureRecognizer:panRec];
    
    
    UILabel * btnTitle = [[UILabel alloc] initWithFrame:CGRectMake( iconBtn.left, iconBtn.bottom + WH_SCALE(5), iconBtn.width, WH_SCALE(15))];
    btnTitle.text = @"我";
    btnTitle.textAlignment = NSTextAlignmentCenter;
    [self addSubview:btnTitle];
    
    UIImageView * heardImg = [[UIImageView alloc] init];
    heardImg.frame = CGRectMake( (iconBtn.width - WH_SCALE(40))/2,  (iconBtn.height - WH_SCALE(40))/2, WH_SCALE(40), WH_SCALE(40));
    heardImg.contentMode = UIViewContentModeScaleAspectFit;
    heardImg.tag = 200;
    heardImg.image = arc4random()%2 ? [UIImage imageNamed:@"rjcs_m"] : [UIImage imageNamed:@"rjcs_wm"];
    [iconBtn addSubview:heardImg];
    

    
#pragma mark 个人的画线
    if (iconBtn.tag == 104)
    {
        iconBtn.frame = CGRectMake(WH_SCALE(120), WH_SCALE(110), WH_SCALE(80), WH_SCALE(80));
        heardImg.frame = CGRectMake( (iconBtn.width - WH_SCALE(48))/2,  (iconBtn.height - WH_SCALE(48))/2, WH_SCALE(48), WH_SCALE(48));
        btnTitle.hidden = YES;
        heardImg.image = [UIImage imageNamed:@"rjcs_me"];
    }
    [self btnBgShadowPanPathAction:iconBtn];
    
}

#pragma mark 点击判断
-(void)tapBtnAction:(UIButton*)senderBtn
{
  
}


#pragma ======================= 手势滑动连接画线效果 =============================
#pragma mark 功能手势滑动的时候、注意移除时候需要刷新
-(void)btnPanAction:(UIPanGestureRecognizer *)rec
{
    UIButton * leftBtn = [[UIButton alloc] init];
    CGPoint touchPoint = [rec locationInView:self];
    if  (rec.state == UIGestureRecognizerStateBegan)
    {
        isPanFlag = NO;
        starPoint = rec.view.center;
        touchIndex = rec.view.tag - 100;
        
    }
    else if (rec.state == UIGestureRecognizerStateChanged)
    {
        movePoint = touchPoint;
        [self setNeedsDisplay];
    }
    else if (rec.state == UIGestureRecognizerStateEnded)
    {
        if (rec.view.tag == 5)
        {
            [self clearAction];
        }else
        {
            
            UIView * supBgVc = [[rec.view superview] superview];
            leftBtn = (UIButton*)rec.view;
            
            for (int i = 0; i < 9; i ++)
            {
                UIButton * btnBgVc = [supBgVc viewWithTag:100+i];
            
                
                if (CGRectContainsPoint(btnBgVc.frame, touchPoint))
                {
                    if (touchIndex == i)
                    {
                        //自己连线自己
                        //                        btnBgVc.backgroundColor = [UIColor yellowColor];
                        return;
                    }else
                    {
                        if (btnBgVc.tag == 104)
                        {
                            DLog(@"连线了我自己的情况==== ");
                        }else
                        {
                            addPositionInt = btnBgVc.tag - 99;
                            addPositionInt = addPositionInt > 4 ? addPositionInt - 1 : addPositionInt;
                        }
//                        [self clearAction];
                        isPanFlag = NO;
                        [self showLayerAction:leftBtn rightBtn:btnBgVc];
                        return;
                    }
                }else
                {
                    [self clearAction];
                }
            }
        }
    }
}

#pragma makr 弹出的毛玻璃动画效果、一系列鸡儿动画、这个自己需求要求的
-(void)showLayerAction:(UIButton*)leftBtn rightBtn:(UIButton*)rightBtn
{
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *effectView = [[UIVisualEffectView alloc] initWithEffect:effect];
    effectView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    [self.window addSubview:effectView];
    
    UIButton * actionBgBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    [actionBgBtn handleControlEvent:UIControlEventTouchUpInside withBlock:^(id sender)
     {
         DLog(@"点击回退时候");
     }];
    actionBgBtn.backgroundColor = RGBA(0, 0, 0, 0.1);
    [self.window addSubview:actionBgBtn];
    
    effectViewSington = effectView;
    actionBtnSington = actionBgBtn;
    
    int showBtnY = WH_SCALE(220);
    leftTopBtn = [self showTopLeftUIButton:leftBtn btnFrame:CGRectMake(WH_SCALE(23) , showBtnY, WH_SCALE(80), WH_SCALE(80))];
    [actionBgBtn addSubview:leftTopBtn];
    
    rightTopBtn = [self showTopLeftUIButton:rightBtn btnFrame:CGRectMake(SCREEN_WIDTH - WH_SCALE(103) , showBtnY, WH_SCALE(80), WH_SCALE(80))];
    [actionBgBtn addSubview:rightTopBtn];
    
    //当前的中部显示线
    UIView * dotView = [[UIView alloc] init];
    dotView.backgroundColor = [UIColor clearColor];
    dotView.frame = CGRectMake((SCREEN_WIDTH - WH_SCALE(70))/2, leftTopBtn.top + leftTopBtn.height/2 - WH_SCALE(5), WH_SCALE(70), WH_SCALE(20));
    [actionBgBtn addSubview:dotView];
    dotViewSington = dotView;
    
    CALayer * animationLayer = [[CALayer alloc] init];
    animationLayer.frame = dotView.layer.bounds;
    [dotView.layer addSublayer:animationLayer];
    
    [self setupAnimationInLayer:animationLayer withFrame:CGRectMake(0, 0, dotView.width, dotView.height) tintColor:RGBA(243, 150, 31, 1) isAnimation:NO];
    
    [self setupAnimationInLayer:animationLayer withFrame:CGRectMake(0, 0, dotView.width, dotView.height) tintColor:[UIColor whiteColor] isAnimation:YES];
    
    [self performSelector:@selector(showHiddenView) withObject:nil afterDelay:2.5];
}

#pragma 弹出的四个鸡儿点的效果、必须要一个白色一个红色的
- (void)setupAnimationInLayer:(CALayer *)layer withFrame:(CGRect)dotFrame tintColor:(UIColor *)tintColor isAnimation:(BOOL)isAnimation
{
    CGFloat duration = 1.0f;
    CGFloat firstBeginTime = CACurrentMediaTime();
    NSArray *beginTimes = @[@(firstBeginTime + 0.2), @(firstBeginTime+0.4), @(firstBeginTime+0.6),@(firstBeginTime+0.8)];
    
    int dotSizeX = WH_SCALE(13);
    int dotW = WH_SCALE(8);
    CGFloat x = (layer.bounds.size.width - dotFrame.size.width) / 2;
    CGFloat y = dotFrame.origin.y;
    
    // 鸡儿的四个点效果、滚动效果、注意两个色
    CAKeyframeAnimation * opacityAnimation = [self createKeyframeAnimationWithKeyPath:@"opacity"];
    opacityAnimation.duration = duration;
    opacityAnimation.values = @[@1.0f,@0.0f];
    opacityAnimation.repeatCount = HUGE_VALF;
    opacityAnimation.autoreverses = YES;
    opacityAnimation.removedOnCompletion = NO;
    opacityAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    
    
    for (int i = 0; i < 4; i++)
    {
        CAShapeLayer *circle = [CAShapeLayer layer];
        UIBezierPath *circlePath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, dotW, dotW) cornerRadius:dotW / 2];
        circle.fillColor = tintColor.CGColor;
        circle.path = circlePath.CGPath;
        circle.frame = CGRectMake(x + dotW * i + dotSizeX * i, y, dotW, dotW);
        [layer addSublayer:circle];
        
        if (isAnimation)
        {
            opacityAnimation.beginTime = [beginTimes[i] floatValue];
            [circle addAnimation:opacityAnimation forKey:@"animation"];
        }
    }
}

- (CAKeyframeAnimation *)createKeyframeAnimationWithKeyPath:(NSString *)keyPath
{
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:keyPath];
    animation.removedOnCompletion = NO;
    return animation;
}

#pragma mark 弹出时候左右两个头像的显示
-(UIButton*)showTopLeftUIButton:(UIButton*)topButton btnFrame:(CGRect)btnFrame
{
    UIImageView * topImg = (UIImageView*)[topButton viewWithTag:200];
    
    UIButton * topBtn = [[UIButton alloc] initWithFrame:CGRectMake(topButton.frameX, topButton.frameY + WH_SCALE(300), topButton.width, topButton.height)];
    topBtn.backgroundColor = [UIColor whiteColor];
    topBtn.layer.masksToBounds = YES;
    topBtn.layer.cornerRadius = WH_SCALE(15);
    [self btnBgShadowPanPathAction:topBtn];
    
    [UIView animateWithDuration:0.3 animations:^{
        topBtn.frame = btnFrame;
        
    } completion:^(BOOL finished)
     {
         
     }];
    
    UIImageView * heardImg = [[UIImageView alloc] init];
    heardImg.frame = CGRectMake( (topBtn.width - WH_SCALE(50))/2,  (topBtn.height - WH_SCALE(50))/2, WH_SCALE(50), WH_SCALE(50));
    heardImg.contentMode = UIViewContentModeScaleAspectFit;
    heardImg.image = topImg.image;
    [topBtn addSubview:heardImg];
    
   
    return topBtn;
}

#pragma mark 当前数据获取后的动画消退、及回调、完整代码为一系列动画拆分
-(void)showHiddenView
{
    self->dotViewSington.alpha = 1;
    [UIView animateWithDuration:0.4 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self->dotViewSington.alpha = 0;
        
    } completion:^(BOOL finished)
     {
         self->dotViewSington.hidden = YES;
         self->actionBtnSington.hidden = YES;
     }];
    
    
    //毛玻璃的、完整代码拆分为跳转下个页面逐步消退
    [UIView animateWithDuration:1.2 animations:^{
        self->effectViewSington.hidden = YES;
        [self clearAction];
    }];
}


#pragma mark 画线

- (void)drawRect:(CGRect)rect
{
    CGContextRef currentContext = UIGraphicsGetCurrentContext();
    
    if (isPanFlag)
    {
        //移除当前的线
        CGContextClearRect(currentContext, rect);
        return;
    }
    /**/
    //设置虚线颜色
    CGContextSetStrokeColorWithColor(currentContext, RGB(243, 177, 89).CGColor);
    //设置虚线宽度
    CGContextSetLineWidth(currentContext, WH_SCALE(3));
    //设置虚线绘制起点
    CGContextMoveToPoint(currentContext, starPoint.x , starPoint.y);
    //设置虚线绘制终点
    CGContextAddLineToPoint(currentContext, movePoint.x, movePoint.y);
    //设置虚线排列的宽度间隔:下面的arr中的数字表示先绘制3个点再绘制1个点
    CGFloat arr[] = {WH_SCALE(4),WH_SCALE(4)};
    //下面最后一个参数“2”代表排列的个数。
    CGContextSetLineDash(currentContext, 0, arr, 2);
    CGContextDrawPath(currentContext, kCGPathStroke);
    
}

- (void)clearAction
{
    isPanFlag = YES;
    [self setNeedsDisplay];
}

#pragma ======================== 一些需要 ====================================

#pragma mark 阴影的效果、有圆角的
-(void)btnBgShadowPanPathAction:(UIButton*)heardBtn
{
    UIView *sBtn3BackView = [UIView new];
    sBtn3BackView.layer.shadowOpacity = 1;
    sBtn3BackView.layer.shadowOffset = CGSizeMake(heardBtn.left - WH_SCALE(8), heardBtn.top - WH_SCALE(3));
    sBtn3BackView.layer.shadowColor = RGB(240, 240, 240).CGColor;
    [[heardBtn superview] insertSubview:sBtn3BackView belowSubview:heardBtn];
    
    UIBezierPath *path3 = [UIBezierPath bezierPathWithRoundedRect:CGRectMake( WH_SCALE(7),  WH_SCALE(2), heardBtn.width + WH_SCALE(4), heardBtn.height + WH_SCALE(4)) cornerRadius:WH_SCALE(15)];
    sBtn3BackView.layer.shadowPath = path3.CGPath;
}

#pragma mark 背景文字的的渐变色、现在都是一个色系
-(void)gradientBgColor:(UILabel*)garColorlb
{
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = CGRectMake(0, 0, garColorlb.width, garColorlb.height);
    [garColorlb.layer addSublayer:gradientLayer];
    
    UIColor *topColor = RGB(250, 217, 146);
    UIColor *botColor = RGB(243, 177, 89);
    gradientLayer.colors = @[(__bridge id)topColor.CGColor,(__bridge id)botColor.CGColor];
    //45度变色(由topColor－>white)
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(0, 1);
    
    UILabel * botLb = [[UILabel alloc] init];
    botLb.frame = garColorlb.bounds;
    botLb.textAlignment = NSTextAlignmentCenter;
    botLb.text = garColorlb.text;
    botLb.textColor = [UIColor whiteColor];
    botLb.font = garColorlb.font;
    [garColorlb addSubview:botLb];
}

@end

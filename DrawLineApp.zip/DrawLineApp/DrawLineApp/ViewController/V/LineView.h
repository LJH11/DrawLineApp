//
//  LineView.h
//  DrawLineApp
//
//  Created by 一只老母猪 on 2019/9/9.
//  Copyright © 2019 〝Cow﹏. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifdef DEBUG
#define DLog(fmt, ...) NSLog((@"[文件名:%s]\n" "[函数名:%s]\n" "[行号:%d] \n" fmt), __FILE__, __FUNCTION__, __LINE__, ##__VA_ARGS__);
#define DeBugLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#define NSLog(...) NSLog(__VA_ARGS__);
#define MyNSLog(FORMAT, ...) fprintf(stderr,"[%s]:[line %d行] %s\n",[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String], __LINE__, [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String]);
#else
#define DLog(...)
#define DeBugLog(...)
#define NSLog(...)
#define MyNSLog(FORMAT, ...) nil
#endif

#define RGBA(R/*红*/, G/*绿*/, B/*蓝*/, A/*透明*/) \
[UIColor colorWithRed:R/255.f green:G/255.f blue:B/255.f alpha:A]
#define RGB(R/*红*/, G/*绿*/, B/*蓝*/) \
[UIColor colorWithRed:R/255.f green:G/255.f blue:B/255.f alpha:1]

#define WH_SCALE(intN) intN * (SCREEN_WIDTH >= 414 ? 1.3 : SCREEN_WIDTH == 375 ? 1.17 : 1)
#define SCREEN_WIDTH  [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height
#define CowNSStringFormat(format,...)[NSString stringWithFormat:format,##__VA_ARGS__]


NS_ASSUME_NONNULL_BEGIN

@interface LineView : UIView
{
    BOOL         isPanFlag;
    CGPoint      starPoint;
    CGPoint      movePoint;
    //拖动的id
    NSInteger    touchIndex;
    NSInteger    addPositionInt;
    
    //当前头像的及动画、不连线调用的话没啥用
    UIView * dotViewSington;
    UIButton * actionBtnSington;
    UIVisualEffectView * effectViewSington;
    UIButton * leftTopBtn, * rightTopBtn;
}

@property (nonatomic, strong) NSArray      *  dataArray;

-(void)showBtnView_UI;

@end

NS_ASSUME_NONNULL_END

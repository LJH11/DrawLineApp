//
//  AppDelegate.h
//  DrawLineApp
//
//  Created by 一只老母猪 on 2019/9/9.
//  Copyright © 2019 〝Cow﹏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

